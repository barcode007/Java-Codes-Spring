import java.io.File;

import org.apache.commons.io.FileUtils;

public class FILEH {

	public static void main(String[] args) {
		
		
		
		String x= FilenameUtils.readFileToString(file);

	}

}
