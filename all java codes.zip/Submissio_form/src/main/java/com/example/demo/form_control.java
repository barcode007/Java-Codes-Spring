package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

/*@Controller    THIS ONE WAS FOR BASIC FORM DETAILS
public class form_control {
	@GetMapping("akash_form")
	public String akash_form()
	{
		return "akash_form";
	}
	
	@PostMapping("/details")
	public String viewdetail(@RequestParam("cid") String cid, 
			@RequestParam ("cname") String cname,
			@RequestParam("cemail")String cemail, ModelMap modelMap)
	{
		modelMap.put("cid", cid);
		modelMap.put("cname", cname);
		modelMap.put("cemail",cemail);
		return "viewdetails";
	}*/

@Controller
public class form_control {
	@Autowired
	customerrepo repo;
	@RequestMapping("/")
	public String details()
	{
		return "akash_form";
	}
	@RequestMapping("/details")
	public String details(customer Customer)
	{
		repo.save(Customer);
		return "akash_form";
		}
	@RequestMapping("/getdetails")
	public String getdetails()
	{
		return  "viewdetails";
	}
	@PostMapping("/getdetails")
	public ModelAndView getdetails(@RequestParam("cid") int cid)
	{ModelAndView mv=new ModelAndView("retrive");
	  customer Customer= repo.findById(cid).orElse(null);
		mv.addObject(Customer);
	  return mv;
	}
	
}