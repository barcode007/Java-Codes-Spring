package com.example.demo;

import org.springframework.data.repository.CrudRepository;

public interface customerrepo extends CrudRepository<customer,Integer>
	{

	
	}


