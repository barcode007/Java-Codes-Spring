package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/* ye phle wala code h normal webb app ka
 * @Controller
public class coursesController {
	@RequestMapping("/courses")
	public String courses()
	{
		System.out.println("Welcome everyone");
		return "course";//without this there will error casue it need a return
	}*/
	//this will still throw error 




/*this one is for passing client data
@Controller
public class coursesController {
	@RequestMapping("/courses")
	public String courses(HttpServletRequest req)
	{ HttpSession session=req.getSession();
		String cname =	req.getParameter("cname");	
	System.out.println("The course name is "+cname);
	session.setAttribute("cname", cname);
		return "course";
}*/

/*this one is for model and view*/
@Controller
public class coursesController {
	@RequestMapping("/courses")
	public ModelAndView courses(@RequestParam("cname")String Coursename,HttpSession session)
	{ 	
	ModelAndView mv=new ModelAndView();
	mv.addObject("cname", Coursename);
	mv.setViewName("course");
		return mv;
		}
}
