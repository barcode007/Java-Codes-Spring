/**
 * 
 */
/**
 * @author akash
 *
 */
module jdbc_test {
	requires java.sql;
}