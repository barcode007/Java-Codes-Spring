package jdbc_test;
import java.sql.*;

public class jdbc_test {
	

	
	   static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/persons";
	   static final String USER = "student";
	   static final String PASS = "student";

	   public static void main(String[] args) {
	      // Open a connection
	      try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
	         Statement stmt = conn.createStatement();
	         ResultSet rs = stmt.executeQuery("Select * from persons" );) {
	         // Extract data from result set
	         while (rs.next()) {
	            // Retrieve by column name
	            System.out.print(" ID:" + rs.getInt("PersonId")+" & ");
	            System.out.print(" First Name: " + rs.getString("FirstName")+" & ");
	            System.out.println(" CIty: " + rs.getString("City"));
	            Statement create_stmt=conn.createStatement();
	            //int rows_affected=create_stmt.executeUpdate("insert into persons"+"(PersonId,LastName,FirstName,Address,City)"+"values"+"(126,'Rawat','Salini','Ashok colony','Roorkee')");
	          //int rows_updt=create_stmt.executeUpdate("update persons"+" set City='pune'"+"where PersonId=124");       
	           
	      
	         }
	       
	         }
	         catch (SQLException e) {
	         e.printStackTrace();
	      } 
             
	      
	 
	   }
	   
	   
	}

