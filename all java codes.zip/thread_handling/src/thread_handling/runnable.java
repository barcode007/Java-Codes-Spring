package thread_handling;

public interface runnable {

}
