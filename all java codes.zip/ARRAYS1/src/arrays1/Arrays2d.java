package arrays1;

public class Arrays2d {

	public static void main(String[] args) {
		int [] [] arr= new int [5][10];

		
		for(int y=2;y<=6;y++)
		{
			for(int x=1;x<=10;x++)
			{
				arr[y-2][x-1]=y*x;
			}
		}
		
		for(int[]i: arr)
		{
			for(int j:i)
			{
				System.out.print(j+" ");
			}
			System.out.println("");
		}
			
	}

}
