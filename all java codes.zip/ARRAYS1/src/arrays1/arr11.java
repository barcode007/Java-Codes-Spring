package arrays1;

import java.util.Scanner;

public class arr11 {

	public static void main(String[] args) {
		System.out.println("Enter a number: ");
		Scanner s1=new Scanner(System.in);

		int arraylength=s1.nextInt();
		int []arr1=new int[arraylength];
		for(int i=0;i<arraylength;i++)
		{
			arr1[i]=s1.nextInt();
		}

		int j= arraylength-1;
		int temp;
		for(int i=0;i>(arraylength-1)/2;i++)
		{

			temp=arr1[j];
			arr1[j]=arr1[i];
			arr1[i]=temp;

			j--;

		} 
		for(int i=0;i<arraylength;i++)
		{
			System.out.print(arr1[i]+" ");
		}


	}

}


