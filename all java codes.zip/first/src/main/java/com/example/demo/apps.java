
//this file is used to handle http request
package com.example.demo;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController  
public class apps {

	@RequestMapping("/hell")
	public String Hello()
	{
		return "hello World";
	}
}
