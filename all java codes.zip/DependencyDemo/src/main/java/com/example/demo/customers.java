package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class customers {

	private String Cust_name;
	private int custid;
	private String Course_name;
	@Autowired
	private technologies techdetails;
	
	public String getCust_name() {
		return Cust_name;
	}
	public void setCust_name(String cust_name) {
		Cust_name = cust_name;
	}
	public int getCustid() {
		return custid;
	}
	public void setCustid(int custid) {
		this.custid = custid;
	}
	public String getCourse_name() {
		return Course_name;
	}
	public void setCourse_name(String course_name) {
		Course_name = course_name;
	}
	public technologies getTechdetails() {
		return techdetails;
	}
	public void setTechdetails(technologies techdetails) {
		this.techdetails = techdetails;
	}
	public void display()
	{
		System.out.println("customers objects returned succesfully");
	   techdetails.tech(); 
	}
}


