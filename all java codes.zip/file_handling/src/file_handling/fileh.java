package file_handling;

import java.io.File;
import java.io.FileReader;



public class fileh {

	public static void main(String[] args) {
	
		File file= new File("C:\\Users\\akash\\Documents\\file1.txt");
		
		String x= FileUtils.
		

         
	}

}
