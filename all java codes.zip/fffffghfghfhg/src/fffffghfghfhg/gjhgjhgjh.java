package fffffghfghfhg;

import java.io.File;


import org.apache.commons.io.FileUtils;

public class gjhgjhgjh {

	public static void main(String[] args) {
		
		File file= new File("C:\\Users\\akash\\Documents\\file1.txt");
		
       String x=FileUtils.read

}
