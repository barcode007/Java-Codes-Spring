package oops_concept;

public class bank_acc {
	
	private String Accno="";
	private String Accname="";
	private int Accbal;
	
	public void deposit(int deposit)
	{
		Accbal=Accbal+deposit;
		System.out.println("Succesfully deposited "+deposit+" amount in your bank");
		System.out.println("The total amount in your bank acount of "+Accname+" with account number "+Accno+ " is "+Accbal+" Rs.");
		
	}
	
	public void withdraw(int withdraw) {
		Accbal=Accbal-withdraw;
		System.out.println("Succesfully withdrawn "+withdraw+" amount from your bank");
		System.out.println("The total amount in your bank acount of "+Accname+" with account number "+Accno+ " is "+Accbal+" Rs.");
	}
	

	public String getAccno() {
		return Accno;
	}

	public void setAccno(String accno) {
		Accno = accno;
	}

	public String getAccname() {
		return Accname;
	}

	public void setAccname(String accname) {
		Accname = accname;
	}

	public int getAccbal() {
		return Accbal;
	}

	public void setAccbal(int accbal) {
		Accbal = accbal;
	}

	
	public bank_acc(String Accno,String Accname,int Accbal)
	{
		System.out.println("your bank amount is "+Accbal);
		this.Accname=Accname;
		this.Accbal=Accbal;
		this.Accno=Accno;
		
	}
}
