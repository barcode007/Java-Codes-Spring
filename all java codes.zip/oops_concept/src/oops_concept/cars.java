package oops_concept;

public class cars {
	
	private String Color="";
	private String brand="";
	private String type="";
	
	public void displaydetails()
	{
		System.out.println("i have a car of color "+Color+ " of brand "+brand+" and is a "+type+" type");
	}

	public void setColor(String color) {
		Color = color;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public void setType(String type) {
		this.type = type;
	}



}
