package oops_concept;

public class multiply {

	public static void main(String[] args) {
		multiply m=new multiply();
		System.out.println(m.multi(10,445));
		
	}

	public int multi(int num1,int num2)
	{
		int num3=num1*num2;
		return num3;
		
	} 
}
