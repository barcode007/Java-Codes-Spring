package oops_concept;

public class bankacc_main {

	public static void main(String[] args) {
		
		bank_acc b1=new bank_acc("1234","Akash",100000);
		b1.deposit(5000);
		b1.withdraw(1000);
		

	}

}
