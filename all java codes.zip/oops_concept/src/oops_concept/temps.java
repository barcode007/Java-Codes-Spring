package oops_concept;

public class temps {

	public static void main(String[] args) {
		cars c1= new cars();
		c1.setBrand("B.M.W");
		c1.setColor("Fire red");
		c1.setType("SUV");

		c1.displaydetails();

	}

}
