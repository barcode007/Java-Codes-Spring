package oops_concept;

public class employees_data {

	public static void main(String[] args) {
		
		employee e1=new employee();
		employee.ename="Akash Rawat";
		e1.eid="A123";
		e1.esalary=57500;	
		
		
		employee e2=new employee();
		employee.ename="Anupam";
		e2.eid="A124";
		e2.esalary=58800;
		
		e1.DisplayBonus(); 
		e2.DisplayBonus();

	}

}
