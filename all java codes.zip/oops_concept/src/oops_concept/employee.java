package oops_concept;

public class employee {
	
	static String ename="";
	double esalary;
	String eid="";
	
	public void DisplayBonus()
	{
	 double bonus= esalary/5;
	 System.out.println("The Bonus of The employee "+ename+" with id "+eid+" is "+bonus);
	}
	
	

}
