package filehhh;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;


public class fileh1 {

	public static void main(String[] args) throws IOException {
		File file=new File("C:\\Users\\akash\\Documents\\file1.txt");
		
		
		String x=FileUtils.readFileToString(file);
		System.out.println(x);

		
		
	}
}
