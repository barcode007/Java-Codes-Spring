package string_buider;

import java.util.Scanner;

public class sccner {

	public static void main(String[] args) {
		System.out.println("please input:");
		Scanner s1=new Scanner(System.in);		
		String  str1= s1.nextLine();
	    System.out.println(str1);
	    
	    
	    
	    
		

	}

}
