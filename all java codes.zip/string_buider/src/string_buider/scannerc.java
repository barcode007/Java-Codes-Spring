package string_buider;

public class scannerc {

	String str;
	
	public void Display()
	{
		System.out.println(str);
	}
}
