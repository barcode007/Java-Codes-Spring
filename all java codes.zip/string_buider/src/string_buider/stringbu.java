package string_buider;
import java.util.Scanner;

public class stringbu {
		public void reverse(String str)
		{
			for(int i=str.length()-1;i>=0;i--)
			{
				System.out.print(str.charAt(i));
			}
		}

	}
