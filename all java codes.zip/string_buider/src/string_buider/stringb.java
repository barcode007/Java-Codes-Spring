package string_buider;

import java.util.Scanner;

public class stringb {

	public static void main(String[] args) {
		
	Scanner s1=new Scanner(System.in);
	String str2=s1.nextLine();
	

	}

}
